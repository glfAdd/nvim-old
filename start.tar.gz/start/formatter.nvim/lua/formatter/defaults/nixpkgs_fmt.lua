return function()
  return {
    exe = "nixpkgs-fmt",
    stdin = true,
    args = {},
  }
end
