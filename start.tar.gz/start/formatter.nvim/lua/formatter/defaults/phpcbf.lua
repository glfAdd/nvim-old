return function()
  return {
    exe = "phpcbf",
    stdin = true,
    ignore_exitcode = true,
  }
end
