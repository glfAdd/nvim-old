return function()
  return {
    exe = "nixfmt",
    stdin = true,
    args = {},
  }
end
