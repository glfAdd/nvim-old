return function()
  return {
    exe = "js-beautify",
    stdin = true,
    try_node_modules = true,
  }
end
