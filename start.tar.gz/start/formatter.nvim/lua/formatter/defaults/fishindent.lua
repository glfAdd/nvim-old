return function()
  return {
    exe = "fish_indent",
    stdin = true,
  }
end
