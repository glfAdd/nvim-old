return function()
  return {
    exe = "deno",
    args = { "fmt", "-" },
    stdin = true,
  }
end
