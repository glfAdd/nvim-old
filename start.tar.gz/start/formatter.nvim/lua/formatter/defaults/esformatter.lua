return function()
  return {
    exe = "esformatter",
    stdin = true,
    try_node_modules = true,
  }
end
