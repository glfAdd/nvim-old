return function()
  return {
    exe = "alejandra",
    stdin = true,
    args = {"--quiet"},
  }
end
