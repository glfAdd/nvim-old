local M = {}

function M.stylish_haskell()
  return {
    exe = "stylish-haskell",
    stdin = true,
  }
end

return M
