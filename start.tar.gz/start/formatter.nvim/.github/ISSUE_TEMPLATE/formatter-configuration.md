---
name: Formatter configuration
about: Report a custom or builtin formatter configuration bug
title: ''
labels: configuration
assignees: Hrle97

---

**Before proceeding**
If you modified the configuration yourself, check that you tried options such as `no_append` or `ignore_exitcode`, and also, if you can, try to run the configuration in your shell.

Shell command and output (optional):

**Which configuration?**
Type (custom or builtin):
Filetype:
Formatter:

Configuration(s) (post all the variants you tried):

**Expected behavior**

**Actual behaviour**

**Additional context**
Add any other context about the problem here.
