local   M = {}

  function M.hello()   

  print "Hello formatter.nvim!" 


end

return   M
