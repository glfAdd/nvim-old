local SignsConfig = require('gitsigns.config').Config.SignsConfig

local M = {Sign = {}, }

































return M
