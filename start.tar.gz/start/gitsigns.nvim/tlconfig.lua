return {
  gen_target = '5.1',
  gen_compat = 'off',
  global_env_def = 'types',
  include_dir = {
    'types', 'teal',
  },
  source_dir = 'teal',
  build_dir = "lua",
}
