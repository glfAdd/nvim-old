

def add(a, b):
    return a + b


def main():
    x = 10
    y = 20
    z = add(x, y)
    return z


main()
